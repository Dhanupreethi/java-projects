package com.db.router.repository;

public enum DBTypeEnum {
	 MAIN, CLIENT_A, CLIENT_B, CLIENT_C;
}
