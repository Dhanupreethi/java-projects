package com.db.router.config;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.db.router.repository.DBContextHolder;
import com.zaxxer.hikari.HikariDataSource;

/**
 * @author Dhanupreethi
 *This class is responsible for different configuration of seesionfactory,
 *transactionmanager, entity manager, configuring different clients
 */

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
		basePackages = "com.db.router",
		entityManagerFactoryRef = "multiEntityManager",
		transactionManagerRef = "multiTransactionManager"
		)
public class PersistenceConfiguration {
	private final String PACKAGE_SCAN = "com.db.router"; 

	@Primary
	@Bean(name = "mainDataSource")
	@ConfigurationProperties("app.datasource.main")
	public DataSource mainDataSource() {
		return DataSourceBuilder.create().type(HikariDataSource.class).build();
	}


	@Bean(name = "clientADataSource")
	@ConfigurationProperties("app.datasource.clienta")
	public DataSource clientADataSource() {
		return DataSourceBuilder.create().type(HikariDataSource.class).build();
	}    


	@Bean(name = "clientBDataSource")
	@ConfigurationProperties("app.datasource.clientb")
	public DataSource clientBDataSource() {
		return DataSourceBuilder.create().type(HikariDataSource.class).build();
	}    

	@Bean(name =  "clientCDataSource")
	@ConfigurationProperties("app.datasource.clientc")
	public DataSource clientCDataSource() {
		return DataSourceBuilder.create().type(HikariDataSource.class).build();
	}    


	/**
	 * @return
	 */
	@Bean(name = "multiRoutingDataSource")
	public DataSource multiRoutingDataSource() {
		System.out.println("current databse in persistent configuration::::");
		ContextDB contextDb=DBContextHolder.getCurrentDatabase();
		Map<Object, Object> targetDataSources = new HashMap<>();
		//Defining list of clients
		contextDb=new ContextDB(101010,"MAIN");
		targetDataSources.put(contextDb, mainDataSource());
		contextDb=new ContextDB(101011,"CLIENT_A");
		targetDataSources.put(contextDb, clientADataSource());
		contextDb=new ContextDB(101012,"CLIENT_B");
		targetDataSources.put(contextDb, clientBDataSource());
		contextDb=new ContextDB(101012,"CLIENT_C");
		targetDataSources.put(contextDb, clientCDataSource());

		MultiRoutingDataSource multiRoutingDataSource = new MultiRoutingDataSource();
		multiRoutingDataSource.setDefaultTargetDataSource(mainDataSource());
		multiRoutingDataSource.setTargetDataSources(targetDataSources);       
		return multiRoutingDataSource;
	}    


	@Bean(name = "multiEntityManager")
	public LocalContainerEntityManagerFactoryBean multiEntityManager() {
		System.out.println("Krsna");
		LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		em.setDataSource(multiRoutingDataSource());
		em.setPackagesToScan(PACKAGE_SCAN);
		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		vendorAdapter.setGenerateDdl(true);
		em.setJpaVendorAdapter(vendorAdapter);
		em.setJpaProperties(jpaProperties());      
		return em;
	}  
	@Bean(name = "multiTransactionManager")
	public PlatformTransactionManager multiTransactionManager() {
		System.out.println("Krsna111111");
		JpaTransactionManager transactionManager
		= new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(
				multiEntityManager().getObject());      
		return transactionManager;
	}    


	@Primary
	@Bean(name = "dbSessionFactory")
	public LocalSessionFactoryBean dbSessionFactory() {
		System.out.println("Krsna22222222222");
		LocalSessionFactoryBean sessionFactoryBean = new LocalSessionFactoryBean();
		sessionFactoryBean.setDataSource(multiRoutingDataSource());
		sessionFactoryBean.setPackagesToScan(PACKAGE_SCAN);
		sessionFactoryBean.setHibernateProperties(hibernateProperties());
		return sessionFactoryBean;
	}    

	private Properties hibernateProperties() {
		Properties properties = new Properties();
		properties.put("hibernate.show_sql", true);
		properties.put("hibernate.format_sql", true);   
		properties.put("hibernate.dialect", "org.hibernate.dialect.PostgreSQLDialect");
		return properties;
	}

	private Properties jpaProperties() {
		Properties properties = new Properties();
		properties.put("hibernate.show_sql", true);
		properties.put("hibernate.format_sql", true); 
		properties.put("hibernate.dialect", "org.hibernate.dialect.PostgreSQLDialect");
		properties.put("hibernate.hbm2ddl.auto","create-drop");
		return properties;

	}
}