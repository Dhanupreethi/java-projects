package com.db.router.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.db.router.config.ContextDB;
import com.db.router.model.Customer;
import com.db.router.repository.DBContextHolder;
 
 
/**
 * @author Dhanupreethi
 *This controller class is used to route to desired database through request
 *Tnis initializes DBContextHolder to desired database
 */
@RestController
public class DatabaseController {
	ContextDB contextDB=new ContextDB(101010,"MAIN");
	@Autowired
	com.db.router.repository.CustomerRepository repository;

	
	@GetMapping(path="/route")
    @ResponseBody
    public List<Customer> getTest(@RequestBody ContextDB contextDB) {
		DBContextHolder.setCurrentDatabase(contextDB);
        List<Customer> customers = repository.findAll();
		List<Customer> CustomerList = new ArrayList<>();
		for (Customer customer : customers) {
			CustomerList.add(new Customer(customer.getFirstName(),customer.getLastName()));
		}
		return CustomerList;
    }
	
}
