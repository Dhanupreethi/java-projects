package com.db.router.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.db.router.model.Customer;

/**
 * @author Dhanupreethi
 *This repository is created to test the application whether it routes to desired database
 */
public interface CustomerRepository extends JpaRepository<Customer, Long>{
List<Customer> findByFirstName(String FirstName);
List<Customer> findAll();

}
