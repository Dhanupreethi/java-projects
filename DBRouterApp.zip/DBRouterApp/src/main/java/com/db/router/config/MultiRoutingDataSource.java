package com.db.router.config;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

import com.db.router.repository.DBContextHolder;

/**
 *@author Dhanupreethi
 *AbstractRoutingDataSource is responsible for dynamically routing 
 *to different data source 
 */
public class MultiRoutingDataSource extends AbstractRoutingDataSource {
  
    @Override
    protected Object determineCurrentLookupKey() {
    	System.out.println("Routing to datasource:::::::::::::"+ DBContextHolder.getCurrentDatabase());
        return DBContextHolder.getCurrentDatabase();
    }
}