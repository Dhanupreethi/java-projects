package com.db.router.repository;

import com.db.router.config.ContextDB;

/**
 * @author Dhanupreethi
 *This class is to hold the cjurrent routed database in ThreadLocal
 */
public class DBContextHolder {
	  private static final ThreadLocal<DBTypeEnum> contextHolder = new ThreadLocal<>();  
	  private static final ThreadLocal<ContextDB> contextDBHolder = new ThreadLocal<>();
	 
	  
	  public static void setCurrentDatabase(ContextDB contextDB) {
	        contextDBHolder.set(contextDB);
	    }    
	  
	  public static ContextDB getCurrentDatabase() {
	        return contextDBHolder.get();
	    }   
	  
	  public static void clear() {
	        contextHolder.remove();
	        contextDBHolder.remove();
	    }
	  
	  
}
