package com.db.router;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Dhanupreethi
 * This app helps to dynamically route to desired data source 
 * through GET request with JSON
 */
@SpringBootApplication
public class DbRouterAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbRouterAppApplication.class, args);
	}

}
