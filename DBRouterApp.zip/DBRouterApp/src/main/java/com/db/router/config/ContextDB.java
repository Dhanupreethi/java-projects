package com.db.router.config;

/**
 * @author Dhanupreethi
 ** This POJO will be passed as JSON payload 
 ** when we send GET request to dynamically route to database
 *
 */
public class ContextDB {

	private long tenantId;
	private String tenantName;

	public ContextDB() {

	}

	public ContextDB(long tenantId, String tenantName) {
		super();
		this.tenantId = tenantId;
		this.tenantName = tenantName;
	}
	public long getTenantId() {
		return tenantId;
	}
	public void setTenantId(long tenantId) {
		this.tenantId = tenantId;
	}
	public String getTenantName() {
		return tenantName;
	}
	public void setTenantName(String tenantName) {
		this.tenantName = tenantName;
	}


	@Override
	public String toString() {
		return "ContextDB [tenantId=" + tenantId + ", tenantName=" + tenantName + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (tenantId ^ (tenantId >>> 32));
		result = prime * result + ((tenantName == null) ? 0 : tenantName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ContextDB other = (ContextDB) obj;
		if (tenantId != other.tenantId)
			return false;
		if (tenantName == null) {
			if (other.tenantName != null)
				return false;
		} else if (!tenantName.equals(other.tenantName))
			return false;
		return true;
	}


}
