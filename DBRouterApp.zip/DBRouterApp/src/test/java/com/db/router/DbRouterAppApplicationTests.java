package com.db.router;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbRouterAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
