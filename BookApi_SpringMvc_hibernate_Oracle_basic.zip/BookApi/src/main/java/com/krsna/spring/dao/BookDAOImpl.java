package com.krsna.spring.dao;

import java.util.List;

import org.hibernate.query.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.krsna.spring.model.Book;

@Repository
public class BookDAOImpl implements BookDAO {
	Session session;
	Transaction transaction;
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public long save(Book book) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().save(book);
		return 0;
	}

	@Override
	public Book get(long id) {
		// TODO Auto-generated method stub
		  Query query = sessionFactory.getCurrentSession().createQuery("from  " + Book.class.getName() + " where id = :id ");
		    query.setParameter("id", id);
		    return (Book) query.uniqueResult();
		
	}

	@Override
	public List<Book> list() {
		// TODO Auto-generated method stub
		List<Book> books=sessionFactory.getCurrentSession().createQuery("from Book").list();
		return books;
	}

	@Override
	public void update(long id, Book book) {
		// TODO Auto-generated method stub
		try {
		session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		Book book1 = (Book) session.load(Book.class, new Long(id));
		System.out.println("Employee object loaded. " + book1);
		transaction.commit();
		Transaction tx7 = session.beginTransaction();
		session.update(book1);
		System.out.println("13. Before committing update transaction");
		tx7.commit();
		System.out.println("14. After committing update transaction");
		}
		catch(Exception e) {
			  if (transaction != null) {
		            transaction.rollback();
		         }
		         e.printStackTrace();
		      } finally {
		         if (session != null) {
		            session.close();
		         }
		}
	}

	@Override
	public void delete(long id) {
	
		try {
		session = sessionFactory.openSession();
		transaction = session.getTransaction();
        transaction.begin();

        //Delete a persistent object
        Book book=session.get(Book.class, id);
        if(book!=null){
           session.delete(book);
           System.out.println("Book is deleted");
        }
		}
		catch (Exception e) {
	         if (transaction != null) {
	            transaction.rollback();
	         }
	         e.printStackTrace();
	      } finally {
	         if (session != null) {
	            session.close();
	         }
        
	}
	}

}
